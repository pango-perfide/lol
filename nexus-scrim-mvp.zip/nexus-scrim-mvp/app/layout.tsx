import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nexus Scrim",
  description: "Recrutement, équipes et scrims League of Legends"
};

const links = [
  ["/", "Accueil"],
  ["/joueurs", "Joueurs"],
  ["/equipes", "Équipes"],
  ["/scrims", "Scrims"],
  ["/classement", "Classement"]
];

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fr">
      <body>
        <header className="nav">
          <Link className="brand" href="/">NEXUS<span>SCRIM</span></Link>
          <nav>{links.map(([href, label]) => <Link key={href} href={href}>{label}</Link>)}</nav>
          <button className="primary">Créer mon profil</button>
        </header>
        <main>{children}</main>
        <footer>Prototype communautaire indépendant - League of Legends et Riot Games sont des marques de Riot Games.</footer>
      </body>
    </html>
  );
}
