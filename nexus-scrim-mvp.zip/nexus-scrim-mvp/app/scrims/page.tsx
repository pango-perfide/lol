const scrims = [
  { team: "Hextech Owls", when: "Mardi - 21h00", range: "Diamond IV à Diamond I", format: "BO3" },
  { team: "Blue Buff Club", when: "Jeudi - 20h30", range: "Emerald IV à Diamond IV", format: "BO3" },
  { team: "Baron Bakers", when: "Dimanche - 18h00", range: "Platinum I à Emerald I", format: "BO5" }
];
export default function ScrimsPage() { return <><header className="pageHead"><div className="eyebrow">Entraînement</div><h1>Demandes de scrim</h1><p>Trouve une équipe de niveau compatible puis confirme le résultat à deux.</p></header><div className="actions"><button className="primary">Publier une demande</button></div><section className="grid" style={{marginTop: 24}}>{scrims.map(s => <article className="card" key={s.team}><span className="badge">Ouvert</span><h2>{s.team}</h2><p>{s.when}</p><div className="metric"><span>Niveau</span><strong>{s.range}</strong></div><div className="metric"><span>Format</span><strong>{s.format}</strong></div><button className="primary" style={{marginTop: 16}}>Proposer le match</button></article>)}</section></>; }
