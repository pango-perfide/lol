import Link from "next/link";
import { news, players, teams } from "@/lib/data";

export default function Home() {
  return <>
    <section className="hero">
      <div>
        <div className="eyebrow">La compétition commence ici</div>
        <h1>Trouve les joueurs qui jouent comme toi.</h1>
        <p>Crée ton roster, recrute selon le niveau et le style de jeu, organise des scrims et grimpe au classement communautaire.</p>
        <div className="actions"><Link className="button" href="/joueurs">Rechercher un joueur</Link><Link className="button secondary" href="/equipes">Créer une équipe</Link></div>
      </div>
      <div className="card heroCard">
        <div className="eyebrow">Profil compatible</div><h2>{players[0].name} #{players[0].tag}</h2>
        <p>{players[0].rank} - {players[0].role} - disponible {players[0].availability}</p>
        <div className="score">92%</div><div className="meta">Compatibilité avec ton roster</div>
        <div>{players[0].styles.map(s => <span className="badge" key={s}>{s}</span>)}</div>
      </div>
    </section>
    <div className="sectionHead"><div><div className="eyebrow">Actualités</div><h2>À la une</h2></div></div>
    <section className="grid">{news.map(n => <article className="card news" key={n.type}><span className="badge">{n.type}</span><h3>{n.title}</h3><p>{n.text}</p></article>)}</section>
    <div className="sectionHead"><div><div className="eyebrow">Communauté</div><h2>En ce moment</h2></div></div>
    <section className="grid">
      <div className="card"><h3>{players.length} profils de démonstration</h3><p>Filtre par rôle, rang, disponibilité et archétype.</p></div>
      <div className="card"><h3>{teams.length} équipes classées</h3><p>Chaque rencontre confirmée fait évoluer le rating.</p></div>
      <div className="card"><h3>Scrims structurés</h3><p>Demandes ouvertes, validation bilatérale et historique.</p></div>
    </section>
  </>;
}
