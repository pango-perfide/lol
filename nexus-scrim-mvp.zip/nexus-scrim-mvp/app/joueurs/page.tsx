"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import { players } from "@/lib/data";

export default function PlayersPage() {
  const [role, setRole] = useState("Tous");
  const [style, setStyle] = useState("");
  const filtered = useMemo(() => players.filter(p => (role === "Tous" || p.role === role) && p.styles.join(" ").toLowerCase().includes(style.toLowerCase())), [role, style]);
  return <>
    <header className="pageHead"><div className="eyebrow">Recrutement</div><h1>Trouver un joueur</h1><p>Les profils ci-dessous utilisent des données fictives pour démontrer le moteur de recherche.</p></header>
    <div className="filters">
      <select value={role} onChange={e => setRole(e.target.value)}>{["Tous", "Top", "Jungle", "Mid", "ADC", "Support"].map(r => <option key={r}>{r}</option>)}</select>
      <input value={style} onChange={e => setStyle(e.target.value)} placeholder="Style : vision, carry..." />
    </div>
    <section className="grid">{filtered.map(p => <Link href={`/joueurs/${p.id}`} className="card" key={p.id}>
      <div className="eyebrow">{p.role} - {p.secondary}</div><h2>{p.name} <span className="meta">#{p.tag}</span></h2><p>{p.rank}</p>
      <div>{p.styles.map(s => <span className="badge" key={s}>{s}</span>)}</div><p className="meta">{p.availability}</p>
    </Link>)}</section>
  </>;
}
