import { notFound } from "next/navigation";
import { players } from "@/lib/data";

export function generateStaticParams() { return players.map(p => ({ id: p.id })); }
export default async function PlayerPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params; const p = players.find(x => x.id === id); if (!p) notFound();
  return <><header className="pageHead"><div className="eyebrow">Profil joueur</div><h1>{p.name} <span className="meta">#{p.tag}</span></h1><p>{p.rank} - {p.role} / {p.secondary}</p></header>
    <section className="grid two">
      <div className="card"><h2>Identité de jeu</h2><p>Disponible : {p.availability}</p><div>{p.styles.map(s => <span className="badge" key={s}>{s}</span>)}</div><div className="actions"><button className="primary">Contacter</button><button className="secondary">Inviter dans l'équipe</button></div></div>
      <div className="card"><h2>Indicateurs récents</h2><div className="metric"><span>CS / min</span><strong>{p.cs}</strong></div><div className="metric"><span>Vision / min</span><strong>{p.vision}</strong></div><div className="metric"><span>KDA</span><strong>{p.kda}</strong></div><div className="metric"><span>Participation</span><strong>{p.kp}%</strong></div><p className="meta">Valeurs fictives. En production, elles seront normalisées selon le rôle, le champion, le rang et la période.</p></div>
    </section></>;
}
