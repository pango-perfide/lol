import { NextRequest, NextResponse } from "next/server";
import { players } from "@/lib/data";

export async function GET(req: NextRequest) {
  const role = req.nextUrl.searchParams.get("role")?.toLowerCase();
  const style = req.nextUrl.searchParams.get("style")?.toLowerCase();
  const result = players.filter(p => (!role || p.role.toLowerCase() === role) && (!style || p.styles.some(s => s.toLowerCase().includes(style))));
  return NextResponse.json({ count: result.length, players: result });
}
