export type Player = {
  id: string; name: string; tag: string; rank: string; role: string; secondary: string;
  team?: string; availability: string; styles: string[]; cs: number; vision: number; kda: number; kp: number;
};

export const players: Player[] = [
  { id: "elyra", name: "Elyra", tag: "EUW", rank: "Diamond II", role: "Support", secondary: "Jungle", availability: "Lun, mer, jeu - 20h", styles: ["Vision", "Playmaker", "Team player"], cs: 1.2, vision: 2.35, kda: 3.9, kp: 68 },
  { id: "kaizen", name: "Kaizen", tag: "EUW", rank: "Emerald I", role: "Jungle", secondary: "Top", availability: "Mar, jeu, dim - 21h", styles: ["Objectifs", "Roamer", "Shotcaller"], cs: 6.4, vision: 1.08, kda: 3.2, kp: 72 },
  { id: "nyx", name: "Nyx", tag: "EUW", rank: "Master", role: "ADC", secondary: "Mid", availability: "Tous les soirs", styles: ["Fermeur", "Carry", "KDA"], cs: 9.1, vision: .62, kda: 4.8, kp: 64 },
  { id: "orion", name: "Orion", tag: "EUW", rank: "Diamond IV", role: "Mid", secondary: "Support", availability: "Ven, sam, dim - 19h", styles: ["Roamer", "Playmaker", "Polyvalent"], cs: 7.8, vision: .84, kda: 3.5, kp: 66 },
  { id: "brume", name: "Brume", tag: "EUW", rank: "Emerald II", role: "Top", secondary: "Jungle", availability: "Lun au jeu - 20h30", styles: ["Fermeur", "Weakside", "Team player"], cs: 8.2, vision: .71, kda: 2.7, kp: 51 }
];

export const teams = [
  { name: "Aegis Five", tag: "AEG", rank: "Master", rating: 1518, wins: 28, losses: 11, need: "Support" },
  { name: "Hextech Owls", tag: "HOW", rank: "Diamond", rating: 1437, wins: 22, losses: 13, need: "Jungle" },
  { name: "Blue Buff Club", tag: "BBC", rank: "Emerald", rating: 1326, wins: 19, losses: 15, need: "ADC" },
  { name: "Baron Bakers", tag: "BBK", rank: "Emerald", rating: 1284, wins: 16, losses: 14, need: "Mid" }
];

export const news = [
  { type: "Patch", title: "Les changements de méta à surveiller", text: "Emplacement prévu pour le résumé du dernier patch officiel et ses impacts par rôle." },
  { type: "Esport", title: "Résultats professionnels", text: "Calendriers, scores et classements des ligues suivies par l'utilisateur." },
  { type: "Mercato", title: "Transferts et rumeurs confirmées", text: "Un flux séparant les annonces officielles des informations non confirmées." }
];
